#_____________________________________________________packages_______________________________________________________________________
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#______________________________________________data path & arrangment_____________________________________________________________________

path=r"C:\Users\Sathish\Desktop\ML\Bank_loan_prediction\bank-additional-full.csv"
#path1=r"c:\users\TOSHIBA-PC\Desktop\bank-additional-full.csv"

names=["age","job","marital","education","default","housing","loan","contact","month","day_of_week","durection","campagin","pdays","previous","poutcome","em.var.rate","cons.price.idx","cons.conf.idx","euribor3m","nr.employed","target"]

#__________________________________________________collecting data___________________________________________________________________

data=pd.read_csv(path,names=names)

#print(data.tail())

#_____________________________________________label encoding/pre-processing__________________________________________________________

from sklearn import preprocessing
le=preprocessing.LabelEncoder()

data["job"]=le.fit_transform(data["job"])
data["marital"]=le.fit_transform(data["marital"])
data["education"]=le.fit_transform(data["education"])
data["default"]=le.fit_transform(data["default"])
data["housing"]=le.fit_transform(data["housing"])
data["loan"]=le.fit_transform(data["loan"])
data["contact"]=le.fit_transform(data["contact"])
data["month"]=le.fit_transform(data["month"])                               
data["day_of_week"]=le.fit_transform(data["day_of_week"])
data["poutcome"]=le.fit_transform(data["poutcome"])
data["target"]=le.fit_transform(data["target"])
#print(data.tail())

#data=data.fillna(0)

#__________________________________________________acess from index_________________________________________________________________
X=data.iloc[ :, :20].values
y=data.iloc[ :,20].values
#print(y)
#print(x)

#______________________________________________corellation and plotting______________________________________________________________________
"""
correlation=data.corr()
print(correlation)

c-orelation=data.corr()#here corelation 
fig=plt.figure()
ax=fig.add_subplot(222)
cax=ax.matshow(corelation,vmax=1,vmin=-1)
#plt.show()


from pandas.plotting import scatter_matrix
scatter_matrix(data)
plt.show()
"""
"""__________________________________________________model bulding____________________________________________________________________"""
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.1768,random_state=2)

#print(X_test.shape)
#print(y_test.shape)


#_________________________________________________________knn_____________________________________________________________________-

from sklearn.neighbors import KNeighborsClassifier
model1=KNeighborsClassifier(n_neighbors=17)
                           

model1.fit(X_train,y_train)

y_pred_knn=model1.predict(X_test)

#y_pred_knn1=model1.predict([[41,12,"married","professional.course","unknown","yes","no","telephone","may","mon",579,1,999,0,"nonexistent",1.1,93.994,-36.4,4.857,5191]])
#print(y_pred_knn1)
from sklearn.metrics import accuracy_score
print("KNN accuracy:",accuracy_score(y_test,y_pred_knn)*100)

#____________________________________________________LogisticRegression_____________________________________________________________

from sklearn.linear_model import LogisticRegression
model2=LogisticRegression()
model2.fit(X_train,y_train)
y_pred_logistic=model2.predict(X_test)

from sklearn.metrics import accuracy_score
print("LogisticRegression accuracy:",accuracy_score(y_test,y_pred_logistic)*100)

#___________________________________________________Naivebayes________________________________________________________________________

from sklearn.naive_bayes import GaussianNB
model3=GaussianNB()
model3.fit(X_train,y_train)
y_pred_naivebayes=model3.predict(X_test)

from sklearn.metrics import accuracy_score
print("Naivebayes accuracy:",accuracy_score(y_test,y_pred_naivebayes)*100)


#___________________________________________________Decision tree____________________________________________________________________

from sklearn import tree
model4=tree.DecisionTreeClassifier(criterion="entropy")
model4.fit(X_train,y_train)
y_pred_decision=model4.predict(X_test)

from sklearn.metrics import accuracy_score
print("decision_trees accuracy:",accuracy_score(y_test,y_pred_decision)*100)


#_____________________________________________________random forest_____________________________________________________________________

from sklearn.ensemble import RandomForestClassifier
model5=RandomForestClassifier()
                           
model5.fit(X_train,y_train)

y_pred_random_forest=model5.predict(X_test)

from sklearn.metrics import accuracy_score
print("Random_forest accuracy:",accuracy_score(y_test,y_pred_random_forest)*100)


#________________________________________________________svm_________________________________________________________________________
from sklearn.svm import SVC
model_svm=SVC(kernel="poly")
model_svm.fit(X_train,y_train)
y_pred_svm=model_svm.predict(X_test) 


from sklearn.metrics import accuracy_score
print("svm accuracy:",accuracy_score(y_test,y_pred_svm)*100)



